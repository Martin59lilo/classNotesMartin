#include "Coach.h"

Coach::Coach(string _name_DT){
    name_DT = _name_DT;
}

Coach::~Coach(){}
